from .deathbot_sim import *

__doc__ = deathbot_sim.__doc__
if hasattr(deathbot_sim, "__all__"):
    __all__ = deathbot_sim.__all__